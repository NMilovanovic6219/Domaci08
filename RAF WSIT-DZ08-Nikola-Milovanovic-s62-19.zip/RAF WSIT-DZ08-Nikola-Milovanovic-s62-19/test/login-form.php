<?php
    require 'connection.php';

    session_start();
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $sql="SELECT * FROM useri WHERE email= '$email' AND password= '$password'";
    $stmt=$pdo->query($sql);
    $user=$stmt->fetch(PDO::FETCH_ASSOC);
    if($user == null){
        header("Location: login.php?Err=Neispravni podaci");
        exit();
    }
    if($user != null){
        if($user['tip'] == 1){
            $_SESSION["isAdmin"] = 1;
            header("Location: korisnici.php");
        }else{
            header("Location: korisnici.php");
        }
    }
?>