<?php
    require "connection.php";
    $id=$_GET['id'];
    $sql="SELECT * FROM useri WHERE id= '$id'";
    $stmt=$pdo-> prepare($sql);
    $stmt->execute();
    $useri=$stmt->fetch(PDO::FETCH_ASSOC);
    
?>

<form method="POST" action="edit-reg.php?id=<?=$id?>">
    <p>
        <label for="emaill">Unesite email: </label>
        <input type="email" name="emaill" id="emaill" value="<?php echo $useri['email']?>">
        <span style="color:red;">
            <?php 
            if (isset($_GET['emailErr']))
                echo $_GET['emailErr'];
            ?>
        </span>
    </p>
    <p>
        <label for="passwordd">Unesite lozinku: </label>
        <input type="password" name="passwordd" id="passwordd" value="<?php echo $useri['password']?>">
        <span style="color:red;">
            <?php 
            if (isset($_GET['passwordErr']))
                echo $_GET['passwordErr'];
            ?>
        </span>
    </p>
    <p>
        <label for="tipp">Unesite tip ovalscenja: </label>
        
        <input type="radio" name="tipp" id="tipp" value="1"> Admin 
		<input type="radio" name="tipp" id="tipp" value="2"/> Korisnik

        <span style="color:red;">
            <?php 
            if (isset($_GET['tipErr']))
                echo $_GET['tipErr'];
            ?>
        </span>
    </p>
    <p>
        <label for="poll">Unesite pol: </label>
        <input type="radio" name="poll" id="poll" value="Musko"> Musko 
		<input type="radio" name="poll" id="poll" value="Zensko"  /> Zenko
        
        <span style="color:red;">
            <?php 
            if (isset($_GET['polErr']))
                echo $_GET['pollErr'];
            ?>
        </span>
    </p>
    <p>
        <label for="telefonn">Unesite telefon: </label>
        <input type="text" name="telefonn" id="telefonn" value="<?php echo $useri['telefon']?>">
        <span style="color:red;">
            <?php 
            if (isset($_GET['telefonErr']))
                echo $_GET['telefonErr'];
            ?>
        </span>
    </p>
    <p>
        <label for="adresaa">Unesite adresu: </label>
        <input type="text" name="adresaa" id="adresaa" value="<?php echo $useri['adresa']?>">
        <span style="color:red;">
            <?php 
            if (isset($_GET['adresaErr']))
                echo $_GET['adresaErr'];
            ?>
        </span>
    </p>
    <input type="submit" value=Edit!>
</form>