<?php

require 'connection.php';

$email = $_POST['email'];
$password = $_POST['password'];
$passwordPotvrda = $_POST['passwordPotvrda'];
$tip = $_POST['tip'];
$pol = $_POST['pol'];
$telefon = $_POST['telefon'];
$adresa = $_POST['adresa'];

$emailErr=$tipErr=$polErr=$adresaErr=$telefonErr=$passwordErr=$passwordPotvrdaErr=$check='';

if(empty($email)){
    $emailErr='Neophodno je uneti email';
}
if(empty($password)){
    $passwordErr='Neophodno je uneti prezime';
}
if(empty($passwordPotvrda)){
    $passwordPotvrdaErr='Mora biti pozitivan broj';
}
if(empty($tip)){
    $tipErr='Mora biti pozitivan broj';
}
if(empty($pol)){
    $polErr='Mora biti veci od 2003';
}
if(empty($adresa)){
    $adresaErr='Mora biti veci od 2003';
}
if(empty($telefon)){
    $telefonErr='Mora biti veci od 2003';
}
if($password != $passwordPotvrda){
    $check = 'Lozinke moraju da budu iste!';
}
if($emailErr!='' || $passwordErr!='' || $passwordPotvrdaErr!='' || $tipErr!='' || $polErr!='' || $adresaErr!='' || $telefonErr!='' || $check!=''){
    header("Location: reg.php?emailErr=$emailErr&passwordErr=$passwordErr&passwordPotvrdaErr=$passwordPotvrdaErr&tipErr=$tipErr&polErr=$polErr&adresaErr=$adresaErr&telefonErr=$telefonErr&check=$check");
    exit();
}


$sqlPrepare="INSERT INTO useri (email,password,tip,pol,telefon,adresa) 
    VALUES (:email, :password, :tip, :pol, :telefon, :adresa)";
$stmt=$pdo->prepare($sqlPrepare);
$stmt->execute([
    'email'=>$email,
    'password' =>$password,
    'tip'=> $tip,
    'pol'=> $pol,
    'telefon'=> $telefon,
    'adresa'=> $adresa
]);
//var_dump($stmt);
header("Location: http://127.0.0.1/test/index.php");
?>