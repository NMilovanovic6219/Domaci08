$(document).ready(function(){

    $('.btn-delete').click(function(){
        id = $(this).attr('id');
        $.ajax({
            url:"brisanje.php",
            type:"POST",
            data: {id:id},
            success: function(){
                window.location.reload();
            }
        });
    });
});