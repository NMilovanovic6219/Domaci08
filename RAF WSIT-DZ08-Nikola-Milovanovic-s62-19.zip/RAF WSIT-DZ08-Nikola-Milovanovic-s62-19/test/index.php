<html>
    <head>
        <script src="script.js"></script>
    </head>
    <body>
        <button onclick="location.href = 'http://127.0.0.1/test/reg.php'">Register</button>
        <button onclick="location.href = 'http://127.0.0.1/test/login.php'">Login</button>
    </body>
</html>