<?php
    require "connection.php";
    $id = $_GET['id'];
    $email = $_POST['emaill'];
    $password = $_POST['passwordd'];
    $tip = $_POST['tipp'];
    $pol = $_POST['poll'];
    $telefon = $_POST['telefonn'];
    $adresa = $_POST['adresaa'];

    $emailErr=$passwordErr=$adresaErr='';
    if(empty($email)){
    $emailErr='Neophodno je uneti email';
    }
    if(empty($password)){
        $passwordErr='Neophodno je uneti lozinku';
    }
    
    
    if(empty($adresa)){
        $adresaErr='Neophodno je uneti adresu';
    }

    if($emailErr!='' || $passwordErr!='' || $adresaErr!=''){
        header("Location: edit.php?emailErr=$emailErr&passwordErr=$passwordErr&adresaErr=$adresaErr&id=$id");
        exit();
    }

    $sql="UPDATE useri SET email='$email',password='$password',tip='$tip',pol='$pol',telefon='$telefon',adresa='$adresa' WHERE id= '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute();
    
    //redirect na home.php
    header("Location: http://127.0.0.1/test/korisnici.php");

?>

