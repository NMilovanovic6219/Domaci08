<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="POST" action="login-form.php">
		<p>
		    <label for="email">Unestite email: </label>
			<input type="email" name="email" id="email">
		</p>
		<p>
			<label for="password">Unesite vasu lozinku: </label>
			<input type="password" name="password" id="password">
		</p>
        <span style="color:red;">
	        <?php 
	            if (isset($_GET['Err']))
	                echo $_GET['Err'];
	            ?>
        </span>
        <button>Login!</button>
    </form>
</body>
</html>