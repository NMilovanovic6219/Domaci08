
<?php
    require 'connection.php';
    session_start();
    $sqlComment="SELECT * FROM useri";
    $stmtComment=$pdo->query($sqlComment);
    $useri=$stmtComment->fetchAll(PDO::FETCH_ASSOC);
?>

<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="style.css">
        <script src="script.js"></script>
    </head>
    <body>
       
        <table id="tabela" border=1>
            <tr bgcolor="grey">
                <td>ID</td>
                <td>Email</td>
                <td>Pol</td>
                <td>Telefon</td>
                <td>Adresa</td>
            </tr>
            <?php foreach($useri as $user) : ?>
                <tr>
                <?php if($_SESSION):?>
                    <?php if($_SESSION['isAdmin']):?>
                        <td><?= $user['id'] ?>
                            <button class="btn-delete" id="<?=$user['id']?>">
                            Obrisi
                            </button>
                                    
                            <a href="edit.php?id=<?=$user['id']?>"> <button>Edituj </button></a>       
                        </td>
                    <?php endif;?>
                    <?php else:?>
                        <td>
                            <?= $user['id'] ?>
                        </td>
                <?php endif;?>
                    <td><?= $user['email'] ?></td>
                    <td><?= $user['pol'] ?></td>
                    <td><?= $user['telefon'] ?></td>
                    <td><?= $user['adresa'] ?></td>
                </tr>
            <?php endforeach; ?>
         </table>
    </body>
</html>
