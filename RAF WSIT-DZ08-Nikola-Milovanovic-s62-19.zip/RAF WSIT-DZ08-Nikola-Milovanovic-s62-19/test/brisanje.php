<?php
    require "connection.php";
    $id=$_POST['id'];
    $sql="DELETE FROM useri WHERE id = '$id'";
    $stmt=$pdo->prepare($sql);
    $stmt->execute([
    	'id'=>$id
    ]);
?>