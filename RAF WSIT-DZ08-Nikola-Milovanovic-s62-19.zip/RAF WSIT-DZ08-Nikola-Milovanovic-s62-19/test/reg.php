<?php
	require 'connection.php';

	$sql="SELECT * FROM useri";
	$stmt=$pdo-> query($sql);
	$useri=$stmt->fetchAll(PDO::FETCH_ASSOC);
	        
?>
<html>
	<head>
		<title>Registracija</title>
	</head>
	<body>

		<form method="POST" action="reg-form.php">
			<p>
				<label for="email">Unestite email: </label>
				<input type="email" name="email" id="email">
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['emailErr']))
	                    echo $_GET['emailErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="password">Unesite vasu lozinku: </label>
				<input type="password" name="password" id="password">
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['passwordErr']))
	                    echo $_GET['passwordErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="passwordPotvrda">Potvrdite unetu lozinku: </label>
				<input type="password" name="passwordPotvrda" id="passwordPotvrda">
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['passwordPotvrdaErr']))
	                    echo $_GET['passwordPotvrdaErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="tip">Unesite tip ovlascenja: </label>
				<input type="radio" name="tip" id="tip" value="1"/> Admin 
				<input type="radio" name="tip" id="tip" value="2"  /> Korisnik 
				
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['tipErr']))
	                    echo $_GET['tipErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="pol">Unesite pol: </label>
				<input type="radio" name="pol" id="pol" value="Musko" /> Musko
				<input type="radio" name="pol" id="pol" value="Zensko" /> Zensko

				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['polErr']))
	                    echo $_GET['polErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="telefon">Unesite broj telefona: </label>
				<input type="text" name="telefon" id="telefon">
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['telefonErr']))
	                    echo $_GET['telefonErr'];
	            	?>
        		</span>
			</p>
			<p>
				<label for="adresa">Unesite vasu adresu: </label>
				<input type="text" name="adresa" id="adresa">
				<span style="color:red;">
	            	<?php 
	                if (isset($_GET['adresaErr']))
	                    echo $_GET['adresaErr'];
	            	?>
        		</span>
			</p>
			<?php 
	                if (isset($_GET['check']))
	                    echo $_GET['check'];
	            	?>
			<input type="submit" name="create" value="Submit!">
		</form>
	</body>
</html>