<?php
    $host='localhost';
    $user='root';
    $pass="";
    $database="test";
    $pdo=new PDO('mysql:host='.$host.';dbname='.$database,$user,$pass);
?>